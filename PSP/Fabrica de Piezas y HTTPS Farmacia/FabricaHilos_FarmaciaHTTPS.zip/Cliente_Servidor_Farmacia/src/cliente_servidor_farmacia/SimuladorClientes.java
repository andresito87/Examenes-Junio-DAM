package cliente_servidor_farmacia;

import java.util.Scanner;

/**
 *
 * @author andres
 */
public class SimuladorClientes {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        int cantidadClientes;

        System.out.print("¿Cuántos clientes quieres simular?: ");
        cantidadClientes = scanner.nextInt();

        Thread[] hilos = new Thread[cantidadClientes];

        // Crear hilos
        for (int i = 0; i < cantidadClientes; i++) {
            int productoRandom = (int) (Math.random() * 3 + 1);

            int cantidadRandom;
            switch (productoRandom) {

                case 1 -> {
                    cantidadRandom = (int) (Math.random() * 3 + 1);
                    hilos[i]
                            = new Cliente("Hilo " + (i+1), "Paracetamol", cantidadRandom);
                }
                case 2 -> {
                    cantidadRandom = (int) (Math.random() * 3 + 1);
                    hilos[i]
                            = new Cliente("Hilo " + (i+1), "Ibuprofeno", cantidadRandom);
                }
                case 3 -> {
                    cantidadRandom = (int) (Math.random() * 3 + 1);
                    hilos[i]
                            = new Cliente("Hilo " + (i+1), "Vitamina C", cantidadRandom);
                }
                default ->
                    throw new AssertionError();
            }
        }

        // Ejecutamos todos los hilos en paralelo
        for (Thread hilo : hilos) {
            hilo.start();
        }

        // Esperar a que todos los hilos terminen
        for (Thread hilo : hilos) {
            try {
                hilo.join();
            } catch (InterruptedException e) {
                System.err.println("Error al esperar el hilo: " + e.getMessage());
            }
        }

        System.out.println("\nTodos los clientes han terminado sus compras.");
    }

}
