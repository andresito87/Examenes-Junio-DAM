package servidorhttps_farmacia;

/**
 *
 * @author andres
 */
public class Mensajes {
    public static final String LINEA_INICIAL_OK = "HTTP/1.1 200 OK";
    public static final String LINEA_INICIAL_NOT_FOUND
            = "HTTP/1.1 404 Not Found";
    public static final String LINEA_INICIAL_BAD_REQUEST
            = "HTTP/1.1 400 Bad Request";
}
